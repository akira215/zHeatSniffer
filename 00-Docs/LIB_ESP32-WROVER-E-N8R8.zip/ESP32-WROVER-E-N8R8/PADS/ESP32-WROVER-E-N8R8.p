*PADS-LIBRARY-PART-TYPES-V9*

ESP32-WROVER-E-N8R8 ESP32WROVEREN8R8 I ANA 7 1 0 0 0
TIMESTAMP 2026.06.04.01.35.44
"Mouser Part Number" 356-ESP32WRVE26464PC
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Espressif-Systems/ESP32-WROVER-E-N8R8?qs=Li%252BoUPsLEnv2mctFVAGY3g%3D%3D
"Manufacturer_Name" Espressif Systems
"Manufacturer_Part_Number" ESP32-WROVER-E-N8R8
"Description" Multiprotocol Modules SMD Module ESP32-WROVER-E, ESP32-D0WD-V3, 3.3V 64Mbit PSRAM, 8 MB SPI flash, PCB Antenna
"Datasheet Link" https://www.espressif.com/sites/default/files/documentation/esp32-wrover-e_esp32-wrover-ie_datasheet_en.pdf
"Geometry.Height" 3.45mm
GATE 1 47 0
ESP32-WROVER-E-N8R8
1 0 U GND_1
2 0 U 3V3
3 0 U EN
4 0 U SENSOR_VP
5 0 U SENSOR_VN
6 0 U IO34
7 0 U IO35
8 0 U IO32
9 0 U IO33
10 0 U IO25
11 0 U IO26
12 0 U IO27
13 0 U IO14
14 0 U IO12
15 0 U GND_2
16 0 U IO13
17 0 U NC_1
18 0 U NC_2
19 0 U NC_3
20 0 U NC_4
21 0 U NC_5
22 0 U NC_6
23 0 U IO15
24 0 U IO2
25 0 U IO0
26 0 U IO4
27 0 U NC_7
28 0 U NC_8
29 0 U IO5
30 0 U IO18
31 0 U IO19
32 0 U NC_9
33 0 U IO21
34 0 U RXD0
35 0 U TXD0
36 0 U IO22
37 0 U IO23
38 0 U GND_3
39 0 U GND_4
40 0 U GND_5
41 0 U GND_6
42 0 U GND_7
43 0 U GND_8
44 0 U GND_9
45 0 U GND_10
46 0 U GND_11
47 0 U GND_12

*END*
*REMARK* SamacSys ECAD Model
15972649/1754298/2.50/47/3/Integrated Circuit
